﻿This Folder contains TCOM Modules that are used by the Scripting Container. To Use these TComModules
copy the modules into "$(TWINCAT3DIR)">Config\Modules"
or extend the "$(TWINCAT3DIR)\Config\Io\TcModuleFolders.xml"
